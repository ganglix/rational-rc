# Raional-RC
Probabilistic deterioration model of reinforced concrete

documentation: docs/build/html/index.html

update documentation:
cd docs/
make clean html
make latexpdf